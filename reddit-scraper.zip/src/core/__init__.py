"""
Core functionality for the Reddit Scraper MCP Server.
""" 