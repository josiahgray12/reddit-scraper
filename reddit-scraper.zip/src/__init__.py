"""
Reddit Scraper MCP Server
A Model Context Protocol server for Reddit data scraping and monitoring.
"""
 
__version__ = "1.0.0" 